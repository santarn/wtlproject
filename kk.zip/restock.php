<?php
include "connection.php";    
$sql = "INSERT INTO inventory(Producttype,Productname,Quantity,Unit)
VALUES ('" . $_POST["Producttype"] . "','" . $_POST["Productname"] . "','" . $_POST["Quantity"] . "','" . $_POST["Unit"] . "')";

if (mysqli_query($conn, $sql)) {
	echo '<script language="javascript">';
  echo 'alert("Inventory Stock Updated")';  //not showing an alert box.
  echo '</script>';
  echo '<script language="javascript">';
	echo 'window.history.back()';
	echo '</script>';} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?>