<?php
include "connection.php";    
$sql = "INSERT INTO listofexe(Firstname,Middlename,Lastname,Email,Salary,Increment,Nationality,Gender,DOB,Accesscode)
VALUES ('" . $_POST["Firstname"] . "','" . $_POST["Middlename"] . "','" . $_POST["Lastname"] . "','" . $_POST["Email"] . "','" . $_POST["Salary"] . "','" . $_POST["Increment"] . "','" . $_POST["Nationality"] . "','" . $_POST["Gender"] . "','" . $_POST["DOB"] . "','" . $_POST["randomnumber"] . "')";

if (mysqli_query($conn, $sql)) {
	echo '<script language="javascript">';
  echo 'alert("Enrollment SuccessFull")';  //not showing an alert box.
  echo '</script>';
  echo '<script language="javascript">';
	echo 'window.history.back()';
	echo '</script>';} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?>