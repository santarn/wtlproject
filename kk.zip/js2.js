function randomnumber() {
document.forms[0].randomnumber.value=(Math.round(Math.random()*9999+1));
}
onload=randomnumber;
function showef(){
	var ef=document.getElementById('ef');
	var inv=document.getElementById('in');
	var s=document.getElementById('s');
	ef.style.display="block";
	inv.style.display="none";
	s.style.display="none";
}

function showin(){
	var ef=document.getElementById('ef');
	var inv=document.getElementById('in');
	var s=document.getElementById('s');
	ef.style.display="none";
	inv.style.display="block";
	s.style.display="none";
}

function shows(){
	var ef=document.getElementById('ef');
	var inv=document.getElementById('in');
	var s=document.getElementById('s');
	ef.style.display="none";
	inv.style.display="none";
	s.style.display="block";
}