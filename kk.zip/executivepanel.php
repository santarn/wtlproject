<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1" />  
<link href="style3.css" rel="stylesheet" />        
<script src="js3.js">
</script>
</head>
<body>

<fieldset class="menu">
<div class="heading">MENU</div>
  <li><button onclick="showef()">Myprofile</button></li>
  <li><button onclick="shows()">Sales</button></li>
  
<li><div class="dropdown">
  <button onclick="showin()">Stock</button>
  <div class="dropdown-content">
    <a href="http://localhost/restock.html">Restock</a>
  </div>
</div></li>
  </fieldset>

  
<fieldset class="eform" id="ef"><legend>My Profile</legend>
<?php    
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "santoshjain2198";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);    
	
if(isset($_POST["Username"], $_POST["Password"], $_POST["Accesscode"])) 
    {     

        $name = $_POST["Username"]; 
        $password = $_POST["Password"]; 
		$acc=$_POST["Accesscode"];
         $sql="SELECT * FROM listofexe WHERE Firstname = '".$password."' AND  Middlename = '".$name."' AND Accesscode='".$acc."'";
        $result1 = mysqli_query($conn, $sql);

        if(mysqli_num_rows($result1) > 0 )
        { 
	echo '<script>';
	echo 'alert("logged in")';
	echo '</script>';
	echo '<script>';
	echo 'window.open("executivepanel.php","_self")';
	echo '</script>';
    
            $_SESSION["logged_in"] = true; 
            $_SESSION["naam"] = $name; 
        }
        else
        {
            echo 'The username or password are incorrect!';
        }
	}
?>  
      
            
</fieldset>

         <style>
		 .inventory{
		display:none;
		position:absolute;
left:400px;
top:30px;
	} table{ border-right:1px solid #ccc; border-bottom:1px solid #ccc; }
tr{ background:#eee; padding:5px; border-left:1px solid #ccc; border-top:1px solid #ccc; }
td{ padding:5px; border-left:1px solid #ccc; border-top:1px solid #ccc; }

	.sales{
		display:none;
		position:absolute;
left:400px;
top:30px;
	}
	.rn{
		display:none;
	}
	</style>
<fieldset class="inventory" id="in">
<?php    
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "santoshjain2198";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);    
$sql = "select * from inventory";    
$result = mysqli_query($conn,$sql);    
?>      
        <table width = "100%" border = "1" cellspacing = "1" cellpadding = "1">    
            <tr>    
                <td>PID</td>    
                <td>Product_Type</td>    
                <td>Product_Name</td>    
                <td>Quantity</td>    
                <td>Unit</td>    
            </tr>    

			
<?php    
    
while($row = mysqli_fetch_object($result)){    
    
    
?>  
      
    <tr>  
        <td>  
            <?php echo $row->PID;?>  
        </td>  
        <td>  
            <?php echo $row->Producttype;?>  
        </td>  
        <td>  
            <?php echo $row->Productname;?>  
        </td>  
        <td>  
            <?php echo $row->Quantity;?>  
        </td>  
        <td>  
            <?php echo $row->Unit;?>  
        </td>  
          
        </tr>
    
     		
<?php } ?>
    </table>
</fieldset>


<fieldset class="sales" id="s">
<?php    
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "santoshjain2198";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);    
$sql = "select * from sales";    
$result = mysqli_query($conn,$sql);    
?>      
        <table width = "100%" border = "1" cellspacing = "1" cellpadding = "1">    
            <tr>    
                <td>SCODE</td>    
                <td>Sales_Target</td>    
                <td>Sales_Achieved</td>    
                <td>Start_Date</td>    
                <td>End_Date</td>    
            </tr>    

			
<?php    
    
while($row = mysqli_fetch_object($result)){    
    
    
?>  
      
    <tr>  
        <td>  
            <?php echo $row->SCODE;?>  
        </td>  
        <td>  
            <?php echo $row->Sales_Target;?>  
        </td>  
        <td>  
            <?php echo $row->Sales_Achieved;?>  
        </td>  
        <td>  
            <?php echo $row->Start_Date;?>  
        </td>  
        <td>  
            <?php echo $row->End_Date;?>  
        </td>  
          
        </tr>
    
     		
<?php } ?>
    </table>

</fieldset>
		 
</body>
</html>