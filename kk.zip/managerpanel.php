<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1" />  
<link href="style2.css" rel="stylesheet" />        
<script src="js2.js">
</script>
</head>
<body>

<fieldset class="menu">
<div class="heading">MENU</div>
  <li><button onclick="showef()">Enroll New Executive</button></li>
  <li><button onclick="showin()">Inventory</button></li>
  <li><button onclick="shows()">Sales</button></li>
  
<li><div class="dropdown">
  <a>More Options</a>
  <div class="dropdown-content">
    <a href="http://localhost/listofexe.php">List of Executives</a>
  </div>
</div></li>

  </fieldset>
<fieldset class="eform" id="ef"><legend>Enrollment Form</legend>
<form action="insert.php" method="POST"><input type="text" id="firstname" class="mytext" name="Firstname" placeholder="Firstname">
<br><br><input type="text" class="mytext" id="middlename" name="Middlename" placeholder="Middlename">
<br><br><input type="text" class="mytext" id="lastname" name="Lastname" placeholder="Lastname"> 
<br><br><input type="text" class="mytext" id="emailid" name="Email" placeholder="EmailID">
<br><br><input type="text" class="others" id="salary" name="Salary" placeholder="Salary(INR)">
<input type="text" class="others" id="increment" name="Increment" placeholder="Increment">
<br><br><label for="nation">Nationality :</label>
<br><select name="Nationality" class="mytext">
   <option value=" "></option>
  <option value="India">India</option>
  <option value="London">America</option>
  <option value="London">London</option>
  <option value="Pakistan">Pakistan</option>
</select><br><br>
<label for="nation">Specify Your Gender :</label>
<input type="radio" name="Gender" id="male" value="Male">Male<input type="radio" name="gender" id="female" value="Female">Female
<br><br>
<div class="others">
  Birthday: <input type="date" name="DOB">
</div><br>
<input type="submit" class="others" value="Submit">
<input name="randomnumber" class="rn" readonly>

</form>
</fieldset>
         <style>
		 .inventory{
		display:none;
		position:absolute;
left:400px;
top:30px;
	} table{ border-right:1px solid #ccc; border-bottom:1px solid #ccc; }
tr{ background:#eee; padding:5px; border-left:1px solid #ccc; border-top:1px solid #ccc; }
td{ padding:5px; border-left:1px solid #ccc; border-top:1px solid #ccc; }

	.sales{
		display:none;
		position:absolute;
left:400px;
top:30px;
	}
	.rn{
		display:none;
	}
	</style>
<fieldset class="inventory" id="in">
<?php    
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "santoshjain2198";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);    
$sql = "select * from inventory";    
$result = mysqli_query($conn,$sql);    
?>      
        <table width = "100%" border = "1" cellspacing = "1" cellpadding = "1">    
            <tr>    
                <td>PID</td>    
                <td>Product_Type</td>    
                <td>Product_Name</td>    
                <td>Quantity</td>    
                <td>Unit</td>    
            </tr>    

			
<?php    
    
while($row = mysqli_fetch_object($result)){    
    
    
?>  
      
    <tr>  
        <td>  
            <?php echo $row->PID;?>  
        </td>  
        <td>  
            <?php echo $row->Producttype;?>  
        </td>  
        <td>  
            <?php echo $row->Productname;?>  
        </td>  
        <td>  
            <?php echo $row->Quantity;?>  
        </td>  
        <td>  
            <?php echo $row->Unit;?>  
        </td>  
          
        </tr>
    
     		
<?php } ?>
    </table>
</fieldset>


<fieldset class="sales" id="s">
<?php    
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "santoshjain2198";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);    
$sql = "select * from sales";    
$result = mysqli_query($conn,$sql);    
?>      
        <table width = "100%" border = "1" cellspacing = "1" cellpadding = "1">    
            <tr>    
                <td>SCODE</td>    
                <td>Sales_Target</td>    
                <td>Sales_Achieved</td>    
                <td>Start_Date</td>    
                <td>End_Date</td>    
            </tr>    

			
<?php    
    
while($row = mysqli_fetch_object($result)){    
    
    
?>  
      
    <tr>  
        <td>  
            <?php echo $row->SCODE;?>  
        </td>  
        <td>  
            <?php echo $row->Sales_Target;?>  
        </td>  
        <td>  
            <?php echo $row->Sales_Achieved;?>  
        </td>  
        <td>  
            <?php echo $row->Start_Date;?>  
        </td>  
        <td>  
            <?php echo $row->End_Date;?>  
        </td>  
          
        </tr>
    
     		
<?php } ?>
    </table>

</fieldset>
		 
</body>
</html>