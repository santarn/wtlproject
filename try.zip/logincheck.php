<?php
include "connection.php";

if(isset($_POST["Username"], $_POST["Password"], $_POST["Accesscode"])) 
    {     

        $name = $_POST["Username"]; 
        $password = $_POST["Password"]; 
		$acc=$_POST["Accesscode"];
         $sql="SELECT Firstname, Middlename FROM listofexe WHERE Firstname = '".$password."' AND  Middlename = '".$name."' AND Accesscode='".$acc."'";
        $result1 = mysqli_query($conn, $sql);

        if(mysqli_num_rows($result1) > 0 )
        { 
	echo '<script>';
	echo 'alert("logged in")';
	echo '</script>';
	echo '<script>';
	echo 'window.open("executivepanel.php","_self")';
	echo '</script>';
    
            $_SESSION["logged_in"] = true; 
            $_SESSION["naam"] = $name; 
        }
        else
        {
            echo 'The username or password are incorrect!';
        }
}
?>