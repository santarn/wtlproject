<?php    
    
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "santoshjain2198";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);    
    
if(isset($_GET['EID'])){    
$sql = "delete from listofexe where EID = '".$_GET['EID']."'";    
$result = mysqli_query($conn,$sql);    
}    
    
$sql = "select * from listofexe";    
$result = mysqli_query($conn,$sql);    
?>    
<html>    
    <body>    
        <table width = "100%" border = "1" cellspacing = "1" cellpadding = "1">    
            <tr>    
                <td>EID</td>    
                <td>Firstname</td>    
                <td>Middlename</td>    
                <td>Lastname</td>    
                <td>Email</td>    
                <td>Salary</td>    
                <td>Increment</td>    
                <td>Nationality</td>    
                <td>Gender</td>    
                <td>DOB</td>        
				<td>Access Code</td>        
                <td colspan = "2">Action</td>    
            </tr>    
           
<?php    
    
while($row = mysqli_fetch_object($result)){    
    
    
?>  
        
    <tr>  
        <td>  
            <?php echo $row->EID;?>  
        </td>  
        <td>  
            <?php echo $row->Firstname;?>  
        </td>  
        <td>  
            <?php echo $row->Middlename;?>  
        </td>  
        <td>  
            <?php echo $row->Lastname;?>  
        </td>  
        <td>  
            <?php echo $row->Email;?>  
        </td>  
        <td>  
            <?php echo $row->Salary;?>  
        </td>  
        <td>  
            <?php echo $row->Increment;?>  
        </td>  
        <td>  
            <?php echo $row->Email;?>  
        </td>  
        <td>
            <?php echo $row->Gender;?>  
        </td>  
        <td>  
            <?php echo $row->DOB;?>  
        </td>  
        <td>  
            <?php echo $row->Accesscode;?>  
        </td>  
          
		  
		  
		  
        <td> <a href="listofexe.php?EID=<?php echo $row->EID;?>" onclick="return confirm('Are You Sure')">Delete</a> | <a href="edit.php?EID =     
            <?php echo $row->EID;?>" onclick="return confirm('Are You Sure')">Edit    
        </a> </td>  
        </tr>
<?php } ?>
</table>    
    </body>    
</html> 		
