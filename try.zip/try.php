<?php    
    
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "santoshjain2198";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);    
    
$sql = "select * from inventory";    
$result = mysqli_query($conn,$sql);    
?>    
<html>    
    <body>    
        <table width = "100%" border = "1" cellspacing = "1" cellpadding = "1">    
            <tr>    
                <td>PID</td>    
                <td>Product_Type</td>    
                <td>Product_Name</td>    
                <td>Quantity</td>    
                <td>Unit</td>    
            </tr>    

			
<?php    
    
while($row = mysqli_fetch_object($result)){    
    
    
?>  
      
    <tr>  
        <td>  
            <?php echo $row->PID;?>  
        </td>  
        <td>  
            <?php echo $row->Producttype;?>  
        </td>  
        <td>  
            <?php echo $row->Productname;?>  
        </td>  
        <td>  
            <?php echo $row->Quantity;?>  
        </td>  
        <td>  
            <?php echo $row->Unit;?>  
        </td>  
          
        </tr>
    
     		
<?php } ?>
    </table></body>           
</html>
