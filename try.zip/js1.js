function rbtn(){
	var f1=document.getElementById("se");
	var f2=document.getElementById("sm");
	var rd=document.getElementsByName("user");
	var i=0;
	if(rd[i].checked)
	{
		f1.style.display="block";
		f2.style.display="none";
	}
	else{
		f2.style.display="block";
		f1.style.display="none";
	}
}

function loginman(){
	var username=document.getElementById("username");
	var password=document.getElementById("password");
	if(username.value==="in-mmadmin"&&password.value==="in-mmadmin")
	{
	  window.open('managerpanel.html','_self');
	  password.value='';
	}
	else{
		alert("Invalid Username Or Password");
		password.value='';
	}
	
}
